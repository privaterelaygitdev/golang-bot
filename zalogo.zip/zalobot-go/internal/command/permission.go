package command

import (
	"slices"

	"github.com/yourname/zalobot-go/internal/bot"
	"github.com/yourname/zalobot-go/internal/store"
)

// Level tính cấp quyền, giống PermissionLevel + CommandLevel của bản Python.
func Level(b *bot.Bot, uid, chatID string) int {
	if uid == b.ID || slices.Contains(b.SuperIDs, uid) {
		return PermSupreme
	}
	s := b.Store.Settings()
	switch {
	case slices.Contains(s.RootAdmin, uid),
		slices.Contains(s.HighAdmin, uid),
		slices.Contains(s.AdminBot, uid):
		return PermRoot // admin 2..4 đều dùng được lệnh tới cấp 4 (giống CommandLevel)
	case slices.Contains(s.GroupAdmin[chatID], uid):
		return PermMod
	}
	return PermUser
}

func defs() []store.CommandConf {
	all := All()
	out := make([]store.CommandConf, 0, len(all))
	for _, c := range all {
		out = append(out, store.CommandConf{Name: c.Name, Permission: c.Permission,
			Cooldown: c.Cooldown, Status: true, Alias: c.Alias})
	}
	return out
}
