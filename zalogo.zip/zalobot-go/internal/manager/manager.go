// Package manager: quản lý nhiều bot (tương đương getClient + StartThreads + botManager).
package manager

import (
	"context"
	"fmt"
	"log/slog"
	"sync"
	"time"

	"github.com/yourname/zalobot-go/internal/bot"
	"github.com/yourname/zalobot-go/internal/command"
	"github.com/yourname/zalobot-go/internal/config"
	"github.com/yourname/zalobot-go/internal/event"
	"github.com/yourname/zalobot-go/internal/gateway/console"
	"github.com/yourname/zalobot-go/internal/gateway/zaloapi"
	"github.com/yourname/zalobot-go/internal/middleware"
	"github.com/yourname/zalobot-go/internal/store"
)

type entry struct {
	bot    *bot.Bot
	cancel context.CancelFunc
}

type Manager struct {
	cfg  *config.Config
	disp *command.Dispatcher
	bus  *event.Bus

	mu   sync.RWMutex
	bots map[string]*entry
	wg   sync.WaitGroup
}

func New(cfg *config.Config, bus *event.Bus) *Manager {
	disp := command.NewDispatcher(
		middleware.SpamGuard(cfg.Spam.Limit, time.Duration(cfg.Spam.WindowSecs)*time.Second),
	)
	return &Manager{cfg: cfg, disp: disp, bus: bus, bots: map[string]*entry{}}
}

func newGateway(b config.Bot) (bot.Gateway, error) {
	switch b.Type {
	case "", "zaloapi":
		if b.Token == "" {
			return nil, fmt.Errorf("bot %s: thiếu token", b.ID)
		}
		return zaloapi.New(b.Token), nil
	case "console": // gateway giả lập để test lệnh ngay trong terminal, xem internal/gateway/console
		return console.New(b.UID, b.Name), nil
	default: // "personal": tự cài, xem internal/gateway/personal/doc.go
		return nil, fmt.Errorf("bot %s: gateway %q chưa được cài", b.ID, b.Type)
	}
}

// router gắn Gateway ↔ Dispatcher/Bus cho một bot.
type router struct {
	m *Manager
	b *bot.Bot
}

func (r router) OnMessage(ctx context.Context, msg *bot.Message) { r.m.disp.Handle(ctx, r.b, msg) }
func (r router) OnEvent(ctx context.Context, e *bot.Event)       { r.m.bus.Emit(ctx, r.b, e) }

func (m *Manager) StartAll(ctx context.Context) {
	for _, bc := range m.cfg.Bots {
		if !bc.Enabled {
			continue
		}
		if err := m.Start(ctx, bc); err != nil {
			slog.Error("không khởi động được bot", "id", bc.ID, "err", err)
		}
	}
}

func (m *Manager) Start(parent context.Context, bc config.Bot) error {
	m.mu.Lock()
	if _, ok := m.bots[bc.ID]; ok {
		m.mu.Unlock()
		return fmt.Errorf("bot %s đã chạy", bc.ID)
	}
	m.mu.Unlock()

	gw, err := newGateway(bc)
	if err != nil {
		return err
	}
	b := bot.New(bc.ID, bc.Name, bc.Main, gw, store.NewBotStore(m.cfg.DataDir, bc.ID), bc.Prefix, m.cfg.SuperIDs)
	if p := b.Store.Settings().Prefix; p != "" {
		b.SetPrefix(p) // prefix lưu trong settings ưu tiên hơn config
	}
	if err := command.SyncStore(b); err != nil {
		slog.Warn("sync Command.json lỗi", "err", err)
	}

	ctx, cancel := context.WithCancel(parent)
	m.mu.Lock()
	m.bots[bc.ID] = &entry{bot: b, cancel: cancel}
	m.mu.Unlock()

	m.wg.Add(1)
	go func() { // mỗi bot một goroutine, tự restart khi gateway lỗi (RunBot retry của bản gốc)
		defer m.wg.Done()
		b.SetRunning(true)
		defer b.SetRunning(false)
		for attempt := 1; ctx.Err() == nil; attempt++ {
			err := gw.Run(ctx, router{m, b})
			if ctx.Err() != nil {
				return
			}
			slog.Error("gateway dừng", "bot", bc.ID, "err", err, "attempt", attempt)
			select {
			case <-ctx.Done():
				return
			case <-time.After(time.Duration(min(attempt, 6)) * 5 * time.Second):
			}
		}
	}()
	slog.Info("bot started", "id", bc.ID, "gateway", gw.Name())
	return nil
}

func (m *Manager) Stop(id string) bool {
	m.mu.Lock()
	e, ok := m.bots[id]
	delete(m.bots, id)
	m.mu.Unlock()
	if ok {
		e.cancel()
	}
	return ok
}

type Info struct {
	ID, Name string
	Main     bool
	Running  bool
	Prefixes []string
}

func (m *Manager) List() []Info {
	m.mu.RLock()
	defer m.mu.RUnlock()
	out := make([]Info, 0, len(m.bots))
	for _, e := range m.bots {
		out = append(out, Info{e.bot.ID, e.bot.Name, e.bot.Main, e.bot.Running(), e.bot.Prefixes()})
	}
	return out
}

func (m *Manager) Get(id string) *bot.Bot {
	m.mu.RLock()
	defer m.mu.RUnlock()
	if e := m.bots[id]; e != nil {
		return e.bot
	}
	return nil
}

func (m *Manager) Wait() { m.wg.Wait() }
