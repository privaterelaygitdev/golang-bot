// Package personal: chỗ đặt Gateway cho TÀI KHOẢN CÁ NHÂN Zalo (bản Python dùng kiểu này:
// đăng nhập QR → sessionCookies + imei → WebSocket zpw_ws, các cmd 501/521/601...).
//
// Đây là API không chính thức: có thể vi phạm điều khoản Zalo, dễ bị khoá tài khoản và
// hay vỡ khi Zalo đổi giao thức nên KHÔNG được cài sẵn ở đây. Nếu bạn tự triển khai,
// chỉ cần cài interface bot.Gateway:
//
//	Run(ctx, h)      // mở WS, giải mã gói, gọi h.OnMessage / h.OnEvent
//	SendText/SendImage/Typing
//
// và đăng ký trong manager.newGateway với type = "personal". Phần còn lại của framework
// (command, quyền, cooldown, store, API) không cần sửa.
package personal
