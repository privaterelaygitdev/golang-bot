// Package event: pub/sub nội bộ đơn giản để tách các automation (welcome, logger, antiundo...).
package event

import (
	"context"
	"sync"

	"github.com/yourname/zalobot-go/internal/bot"
)

type Func func(ctx context.Context, b *bot.Bot, e *bot.Event)

type Bus struct {
	mu   sync.RWMutex
	subs map[string][]Func
}

func NewBus() *Bus { return &Bus{subs: map[string][]Func{}} }

// On đăng ký handler cho loại sự kiện ("*" = tất cả).
func (b *Bus) On(typ string, f Func) {
	b.mu.Lock()
	b.subs[typ] = append(b.subs[typ], f)
	b.mu.Unlock()
}

func (b *Bus) Emit(ctx context.Context, bt *bot.Bot, e *bot.Event) {
	b.mu.RLock()
	list := append(append([]Func{}, b.subs[e.Type]...), b.subs["*"]...)
	b.mu.RUnlock()
	for _, f := range list {
		go f(ctx, bt, e)
	}
}
