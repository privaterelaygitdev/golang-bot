// Package modules nạp mọi nhóm lệnh: mỗi nhóm là một package con dưới
// internal/modules/, tự đăng ký lệnh bằng init() -> command.Register(...).
//
// File NÀY là nơi DUY NHẤT main.go cần biết tới.
//   - Thêm MỘT LỆNH vào nhóm đã có sẵn (vd: thêm file mới vào internal/modules/fun/):
//     chỉ cần thả file .go vào, build lại — không cần sửa gì ở đây lẫn main.go,
//     vì mọi file cùng thư mục tự động thuộc cùng package.
//   - Thêm MỘT NHÓM LỆNH MỚI (thư mục mới, vd internal/modules/admin/):
//     thêm đúng 1 dòng import trống bên dưới, build lại.
//
// Go biên dịch tĩnh nên vẫn cần build lại mỗi khi có file/module mới — không
// có kiểu "quét thư mục lúc chạy" như commandLoader bên bản Python.
package modules

import (
	_ "github.com/yourname/zalobot-go/internal/modules/core"
	_ "github.com/yourname/zalobot-go/internal/modules/fun"

	// Thêm module mới ở đây, ví dụ:
	// _ "github.com/yourname/zalobot-go/internal/modules/admin"
	// _ "github.com/yourname/zalobot-go/internal/modules/game"
)
