package command

import (
	"context"
	"strings"
	"sync"
	"testing"

	"github.com/yourname/zalobot-go/internal/bot"
	"github.com/yourname/zalobot-go/internal/store"
)

type fakeGW struct {
	mu   sync.Mutex
	sent []string
}

func (f *fakeGW) Name() string                                            { return "fake" }
func (f *fakeGW) Run(context.Context, bot.Handler) error                  { return nil }
func (f *fakeGW) SendImage(context.Context, string, string, string) error { return nil }
func (f *fakeGW) Typing(context.Context, string) error                    { return nil }
func (f *fakeGW) SendText(_ context.Context, _, t string) error {
	f.mu.Lock()
	f.sent = append(f.sent, t)
	f.mu.Unlock()
	return nil
}

func TestDispatch(t *testing.T) {
	Register(&Command{Name: "t_hello", Alias: []string{"t_hi"}, Cooldown: 60,
		Run: func(c *Context) error { return c.Reply("hi " + c.Raw) }})
	Register(&Command{Name: "t_admin", Permission: PermAdmin,
		Run: func(c *Context) error { return c.Reply("secret") }})

	gw := &fakeGW{}
	b := bot.New("b1", "t", true, gw, store.NewBotStore(t.TempDir(), "b1"), ".", []string{"boss"})
	if err := SyncStore(b); err != nil {
		t.Fatal(err)
	}
	d := NewDispatcher()
	send := func(from, text string) {
		d.Handle(context.Background(), b, &bot.Message{FromID: from, ChatID: "c", Text: text})
	}

	send("u1", "t_hello x")  // không prefix → bỏ qua
	send("u1", ".t_hello x") // chạy
	send("u1", ".t_hello x") // cooldown
	send("u2", ".t_hi y")    // alias
	send("u1", ".t_admin")   // thiếu quyền
	send("boss", ".t_admin") // super admin

	got := strings.Join(gw.sent, "|")
	for _, want := range []string{"hi x", "hi y", "không đủ quyền", "đợi", "secret"} {
		if !strings.Contains(got, want) {
			t.Errorf("thiếu %q trong %q", want, got)
		}
	}
	if len(gw.sent) != 5 {
		t.Errorf("mong 5 phản hồi, có %d: %v", len(gw.sent), gw.sent)
	}
}
