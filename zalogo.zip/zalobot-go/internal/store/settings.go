package store

import (
	"path/filepath"
	"slices"
)

// Settings: tương đương assets/storage/{uid}/settings.json.
type Settings struct {
	RootAdmin  []string            `json:"rootAdmin"`
	HighAdmin  []string            `json:"highAdmin"`
	AdminBot   []string            `json:"adminBot"`
	GroupAdmin map[string][]string `json:"groupAdmin"`
	AllowGroup []string            `json:"allowGroup"`
	ListenPriv bool                `json:"listenPrivate"`
	Prefix     string              `json:"prefix"`
}

// CommandConf: tương đương Command.json (ghi đè quyền/cooldown/alias theo từng bot).
type CommandConf struct {
	Name       string   `json:"name"`
	Permission int      `json:"permission"`
	Cooldown   float64  `json:"cooldown"`
	Status     bool     `json:"status"`
	Alias      []string `json:"alias"`
}

type commandFile struct {
	Command []CommandConf `json:"command"`
}

// BotStore gom dữ liệu của MỘT bot, thư mục data/<botID>/.
type BotStore struct {
	settings *JSON
	commands *JSON
}

func NewBotStore(dataDir, botID string) *BotStore {
	d := filepath.Join(dataDir, botID)
	return &BotStore{
		settings: NewJSON(filepath.Join(d, "settings.json")),
		commands: NewJSON(filepath.Join(d, "Command.json")),
	}
}

func (b *BotStore) Settings() Settings {
	var s Settings
	_ = b.settings.Load(&s)
	return s
}

func (b *BotStore) UpdateSettings(fn func(s *Settings)) error {
	var s Settings
	return b.settings.Update(&s, func() { fn(&s) })
}

func (b *BotStore) CommandConfs() map[string]CommandConf {
	var f commandFile
	_ = b.commands.Load(&f)
	m := make(map[string]CommandConf, len(f.Command))
	for _, c := range f.Command {
		m[c.Name] = c
	}
	return m
}

// SyncCommands đồng bộ danh sách lệnh trong code vào Command.json (giữ lại phần user đã chỉnh).
func (b *BotStore) SyncCommands(defs []CommandConf) error {
	var f commandFile
	return b.commands.Update(&f, func() {
		old := map[string]CommandConf{}
		for _, c := range f.Command {
			old[c.Name] = c
		}
		out := make([]CommandConf, 0, len(defs))
		for _, d := range defs {
			if o, ok := old[d.Name]; ok {
				for _, a := range d.Alias {
					if !slices.Contains(o.Alias, a) {
						o.Alias = append(o.Alias, a)
					}
				}
				out = append(out, o)
				continue
			}
			out = append(out, d)
		}
		f.Command = out
	})
}
