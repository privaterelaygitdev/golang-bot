// Package zaloapi: Gateway cho Zalo Bot Platform chính thức (https://bot.zapps.me).
// Dùng long-polling getUpdates (phù hợp dev/nhỏ); production nên chuyển sang webhook.
//
// LƯU Ý: schema update bên dưới dựa trên SDK cộng đồng, hãy đối chiếu tài liệu chính thức
// và chỉnh struct `update` nếu khác.
package zaloapi

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"log/slog"
	"net/http"
	"time"

	"github.com/yourname/zalobot-go/internal/bot"
)

const defaultBase = "https://bot-api.zaloplatforms.com"

type Client struct {
	token string
	base  string
	http  *http.Client
}

func New(token string) *Client {
	return &Client{token: token, base: defaultBase, http: &http.Client{Timeout: 60 * time.Second}}
}

func (c *Client) Name() string { return "zalo-bot-api" }

type envelope struct {
	OK          bool            `json:"ok"`
	Result      json.RawMessage `json:"result"`
	ErrorCode   int             `json:"error_code"`
	Description string          `json:"description"`
}

func (c *Client) call(ctx context.Context, method string, body any) (json.RawMessage, error) {
	b, _ := json.Marshal(body)
	req, err := http.NewRequestWithContext(ctx, http.MethodPost,
		fmt.Sprintf("%s/bot%s/%s", c.base, c.token, method), bytes.NewReader(b))
	if err != nil {
		return nil, err
	}
	req.Header.Set("Content-Type", "application/json")
	resp, err := c.http.Do(req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()
	raw, _ := io.ReadAll(resp.Body)
	var env envelope
	if err := json.Unmarshal(raw, &env); err != nil {
		return nil, fmt.Errorf("%s: phản hồi không hợp lệ (%d)", method, resp.StatusCode)
	}
	if !env.OK {
		return nil, fmt.Errorf("%s: %d %s", method, env.ErrorCode, env.Description)
	}
	return env.Result, nil
}

type update struct {
	EventName string `json:"event_name"`
	Message   *struct {
		MessageID string `json:"message_id"`
		Text      string `json:"text"`
		Chat      struct {
			ID       string `json:"id"`
			ChatType string `json:"chat_type"`
		} `json:"chat"`
		From struct {
			ID          string `json:"id"`
			DisplayName string `json:"display_name"`
			IsBot       bool   `json:"is_bot"`
		} `json:"from"`
	} `json:"message"`
}

// Run: vòng long-polling, tự retry khi lỗi mạng.
func (c *Client) Run(ctx context.Context, h bot.Handler) error {
	if _, err := c.call(ctx, "getMe", map[string]any{}); err != nil {
		return fmt.Errorf("token không hợp lệ: %w", err)
	}
	backoff := time.Second
	for ctx.Err() == nil {
		res, err := c.call(ctx, "getUpdates", map[string]any{"timeout": "30"})
		if err != nil {
			slog.Warn("getUpdates lỗi", "err", err, "retry", backoff)
			select {
			case <-ctx.Done():
				return nil
			case <-time.After(backoff):
			}
			if backoff < 30*time.Second {
				backoff *= 2
			}
			continue
		}
		backoff = time.Second
		for _, u := range parseUpdates(res) {
			if u.Message == nil || u.Message.From.IsBot {
				continue
			}
			m := &bot.Message{
				ID: u.Message.MessageID, ChatID: u.Message.Chat.ID,
				ChatType: bot.ChatType(u.Message.Chat.ChatType),
				FromID:   u.Message.From.ID, FromName: u.Message.From.DisplayName,
				Text: u.Message.Text, Raw: u,
			}
			go h.OnMessage(ctx, m) // mỗi tin xử lý song song, không chặn vòng poll
		}
	}
	return nil
}

func parseUpdates(raw json.RawMessage) []update {
	if len(raw) == 0 || string(raw) == "null" {
		return nil
	}
	var many []update
	if json.Unmarshal(raw, &many) == nil {
		return many
	}
	var one update
	if json.Unmarshal(raw, &one) == nil {
		return []update{one}
	}
	return nil
}

func (c *Client) SendText(ctx context.Context, chatID, text string) error {
	_, err := c.call(ctx, "sendMessage", map[string]any{"chat_id": chatID, "text": text})
	return err
}

func (c *Client) SendImage(ctx context.Context, chatID, url, caption string) error {
	_, err := c.call(ctx, "sendPhoto", map[string]any{"chat_id": chatID, "photo": url, "caption": caption})
	return err
}

func (c *Client) Typing(ctx context.Context, chatID string) error {
	_, err := c.call(ctx, "sendChatAction", map[string]any{"chat_id": chatID, "action": "typing"})
	return err
}
