// Package config: đọc configs/config.json (thay login.json + database-config.json).
package config

import (
	"encoding/json"
	"fmt"
	"os"
)

type Bot struct {
	ID       string `json:"id"`
	Name     string `json:"name"`
	Type     string `json:"type"`  // "zaloapi" | "personal"
	Token    string `json:"token"` // hoặc dùng tokenEnv (bắt buộc khi type=zaloapi)
	TokenEnv string `json:"tokenEnv"`

	// Các trường dưới đây CHỈ dùng khi type="personal" (đăng nhập bằng chính
	// session tài khoản cá nhân: uid + imei + cookie, không cần token).
	// LƯU Ý: internal/gateway/personal hiện CHƯA cài kết nối thật — các
	// trường này đã đọc/validate sẵn, nhưng chưa có gateway nào dùng tới cho
	// tới khi bạn tự triển khai xong phần đó.
	UID     string            `json:"uid,omitempty"`
	IMEI    string            `json:"imei,omitempty"`
	Cookies map[string]string `json:"cookies,omitempty"`

	Prefix  string `json:"prefix"`
	Main    bool   `json:"main"`
	Enabled bool   `json:"enabled"`
}

type Config struct {
	DataDir   string   `json:"dataDir"`
	APIAddr   string   `json:"apiAddr"`
	APIKeyEnv string   `json:"apiKeyEnv"`
	SuperIDs  []string `json:"superIds"`
	Spam      struct {
		Limit      int `json:"limit"`
		WindowSecs int `json:"windowSecs"`
	} `json:"spam"`
	Bots []Bot `json:"bots"`
}

func Load(path string) (*Config, error) {
	b, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}
	var c Config
	if err := json.Unmarshal(b, &c); err != nil {
		return nil, err
	}
	if c.DataDir == "" {
		c.DataDir = "data"
	}
	if c.Spam.Limit == 0 {
		c.Spam.Limit, c.Spam.WindowSecs = 5, 10
	}
	for i := range c.Bots {
		bt := &c.Bots[i]
		if bt.TokenEnv != "" {
			bt.Token = os.Getenv(bt.TokenEnv)
		}
		if bt.ID == "" {
			return nil, fmt.Errorf("bots[%d]: thiếu id", i)
		}
		switch bt.Type {
		case "", "zaloapi":
			if bt.Token == "" {
				return nil, fmt.Errorf("bot %s: type=zaloapi cần token hoặc tokenEnv", bt.ID)
			}
		case "personal":
			if bt.UID == "" || bt.IMEI == "" || len(bt.Cookies) == 0 {
				return nil, fmt.Errorf("bot %s: type=personal cần đủ uid, imei, cookies", bt.ID)
			}
		}
	}
	return &c, nil
}
