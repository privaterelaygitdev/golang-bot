module github.com/yourname/zalobot-go

go 1.22
