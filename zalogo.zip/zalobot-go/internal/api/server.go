// Package api: REST quản lý bot từ xa (thay app/core/server Flask).
package api

import (
	"context"
	"crypto/subtle"
	"encoding/json"
	"net/http"
	"strings"
	"time"

	"github.com/yourname/zalobot-go/internal/manager"
)

type Server struct {
	m      *manager.Manager
	apiKey string
	srv    *http.Server
}

func New(m *manager.Manager, addr, apiKey string) *Server {
	s := &Server{m: m, apiKey: apiKey}
	mux := http.NewServeMux()
	mux.HandleFunc("GET /healthz", func(w http.ResponseWriter, _ *http.Request) { w.Write([]byte("ok")) })
	mux.HandleFunc("GET /api/bots", s.auth(s.listBots))
	mux.HandleFunc("POST /api/bots/{id}/stop", s.auth(s.stopBot))
	mux.HandleFunc("POST /api/bots/{id}/send", s.auth(s.send))
	s.srv = &http.Server{Addr: addr, Handler: mux, ReadHeaderTimeout: 5 * time.Second}
	return s
}

func (s *Server) Run(ctx context.Context) error {
	go func() {
		<-ctx.Done()
		c, cancel := context.WithTimeout(context.Background(), 5*time.Second)
		defer cancel()
		_ = s.srv.Shutdown(c)
	}()
	if err := s.srv.ListenAndServe(); err != http.ErrServerClosed {
		return err
	}
	return nil
}

// auth: bắt buộc Bearer key; nếu chưa cấu hình key thì khoá hết (an toàn mặc định).
func (s *Server) auth(next http.HandlerFunc) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		got := strings.TrimPrefix(r.Header.Get("Authorization"), "Bearer ")
		if s.apiKey == "" || subtle.ConstantTimeCompare([]byte(got), []byte(s.apiKey)) != 1 {
			http.Error(w, "unauthorized", http.StatusUnauthorized)
			return
		}
		next(w, r)
	}
}

func (s *Server) listBots(w http.ResponseWriter, _ *http.Request) {
	_ = json.NewEncoder(w).Encode(s.m.List())
}

func (s *Server) stopBot(w http.ResponseWriter, r *http.Request) {
	if !s.m.Stop(r.PathValue("id")) {
		http.NotFound(w, r)
		return
	}
	w.WriteHeader(http.StatusNoContent)
}

func (s *Server) send(w http.ResponseWriter, r *http.Request) {
	b := s.m.Get(r.PathValue("id"))
	if b == nil {
		http.NotFound(w, r)
		return
	}
	var req struct{ ChatID, Text string }
	if json.NewDecoder(http.MaxBytesReader(w, r.Body, 1<<20)).Decode(&req) != nil || req.ChatID == "" {
		http.Error(w, "bad request", http.StatusBadRequest)
		return
	}
	if err := b.GW.SendText(r.Context(), req.ChatID, req.Text); err != nil {
		http.Error(w, err.Error(), http.StatusBadGateway)
		return
	}
	w.WriteHeader(http.StatusNoContent)
}
