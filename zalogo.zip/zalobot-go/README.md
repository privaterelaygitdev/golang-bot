# zalobot-go

Khung (skeleton) bot Zalo đa tài khoản bằng Go, thiết kế theo cấu trúc của bot Python `zalo-go.zip`.

## Cấu trúc

```
cmd/zalobot/main.go          Entry: đọc config → Manager.StartAll → API → graceful shutdown
configs/config.example.json  Thay login.json + database-config.json (token lấy từ biến môi trường)
internal/
  bot/         Kiểu lõi: Message, Event, Gateway, Handler + struct Bot (một instance)
  gateway/
    zaloapi/   Gateway Zalo Bot Platform chính thức (long-poll getUpdates, sendMessage…)
    personal/  Chỗ cắm gateway tài khoản cá nhân (WebSocket) – KHÔNG cài sẵn
  command/     Registry + Dispatcher (prefix, alias, quyền 0-5, cooldown, middleware)
  commands/    Mỗi file = một nhóm lệnh, tự đăng ký bằng init()
  middleware/  spamGuard, blacklist…
  event/       Bus sự kiện (join/leave, reaction, undo…) cho automations
  store/       JSON atomic: settings.json, Command.json theo từng bot
  manager/     Đa bot: start/stop, goroutine riêng, tự retry
  api/         REST quản lý bot (Bearer key)
```

## Ánh xạ Python → Go

| Python | Go |
|---|---|
| `main.py` `ebugZLB` (mixin) | `bot.Bot` + `command.Dispatcher` (composition) |
| `app/core/login` `getClient`, `StartThreads` | `manager.Manager` (map + goroutine + context) |
| `functions/api` ZaloAPI + WebSocket | interface `bot.Gateway` |
| `messageListener` → `MessageHandler` | `Handler.OnMessage` → `Dispatcher.Handle` |
| `commandLoader` quét `src/` + `dependencies` | `command.Register()` trong `init()` |
| `PermissionLevel` (0..5) | `command.Level` |
| `CheckCooldown` | `Dispatcher.checkCooldown` |
| `spamGuard`, anti hooks | `middleware.*` |
| `assets/storage/{uid}/*.json` | `store.BotStore` (`data/<botID>/`) |
| `src/events/*` | `event.Bus` |
| Flask server / botweb | `internal/api` (net/http) |

## Chạy

```bash
cp configs/config.example.json configs/config.json
export ZALO_BOT_TOKEN_MAIN=xxxx ZALOBOT_API_KEY=$(openssl rand -hex 16)
go run ./cmd/zalobot
```

## Thêm lệnh mới

Thêm lệnh vào một module đã có (vd: `internal/modules/fun/`) — chỉ cần thả file `.go`
mới vào, không sửa gì ở nơi khác:

```go
// internal/modules/fun/hello.go
func init() {
    command.Register(&command.Command{
        Name: "hello", Alias: []string{"hi"}, Description: "Chào",
        Permission: command.PermUser, Cooldown: 3,
        Run: func(c *command.Context) error { return c.Reply("Xin chào " + c.Msg.FromName) },
    })
}
```

Thêm hẳn một **nhóm lệnh mới** (thư mục mới, vd `internal/modules/admin/`): viết
package như trên rồi thêm đúng 1 dòng import trống vào `internal/modules/register.go`.
`main.go` thì không bao giờ phải sửa nữa — nó chỉ import `internal/modules` một lần.

## Việc nên làm tiếp
- Webhook cho `zaloapi` (thay long-poll), `/webhook/{botID}` trong `internal/api`.
- Lưu DB (SQLite/Mongo) cho topchat, log, undo thay vì JSON.
- Automations: welcome, anti-spam link, auto-reply đăng ký vào `event.Bus`.
- Hot-reload lệnh: Go không nạp plugin động tiện như Python; dùng bật/tắt `status` trong `Command.json`
  hoặc tách lệnh thành tiến trình/HTTP riêng nếu thật sự cần.
