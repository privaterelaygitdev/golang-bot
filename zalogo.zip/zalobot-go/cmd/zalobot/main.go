package main

import (
	"context"
	"flag"
	"log/slog"
	"os"
	"os/signal"
	"syscall"

	"github.com/yourname/zalobot-go/internal/api"
	"github.com/yourname/zalobot-go/internal/config"
	"github.com/yourname/zalobot-go/internal/event"
	"github.com/yourname/zalobot-go/internal/manager"

	_ "github.com/yourname/zalobot-go/internal/modules" // nạp toàn bộ module lệnh (xem internal/modules/register.go)
)

func main() {
	cfgPath := flag.String("config", "configs/config.json", "đường dẫn config")
	flag.Parse()

	cfg, err := config.Load(*cfgPath)
	if err != nil {
		slog.Error("đọc config lỗi", "err", err)
		os.Exit(1)
	}

	// Graceful shutdown (tương đương eventBoolsShutdown)
	ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer stop()

	bus := event.NewBus()
	mgr := manager.New(cfg, bus)
	mgr.StartAll(ctx)

	if cfg.APIAddr != "" {
		go func() {
			if err := api.New(mgr, cfg.APIAddr, os.Getenv(cfg.APIKeyEnv)).Run(ctx); err != nil {
				slog.Error("api lỗi", "err", err)
			}
		}()
	}

	<-ctx.Done()
	slog.Info("đang tắt...")
	mgr.Wait()
}
