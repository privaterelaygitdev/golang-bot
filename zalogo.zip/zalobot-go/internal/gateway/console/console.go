// Package console là một Gateway giả lập chạy ngay trong terminal — gõ lệnh
// trực tiếp vào stdin, bot trả lời ra stdout. Dùng để TEST nhanh dispatcher +
// toàn bộ module lệnh (internal/modules/...) mà KHÔNG cần kết nối Zalo thật,
// rất hữu ích khi gateway thật (personal) chưa cài xong.
//
// Cách dùng: đặt "type": "console" cho một bot trong configs/config.json,
// chạy `go run ./cmd/zalobot -config configs/config.json`, rồi gõ thẳng:
//
//	.menu
//	.ping
//	.hello
//
// Gõ "exit" hoặc Ctrl+C để thoát.
package console

import (
	"bufio"
	"context"
	"fmt"
	"os"
	"strings"

	"github.com/yourname/zalobot-go/internal/bot"
)

type Client struct {
	chatID string
	fromID string
	name   string
}

// New tạo gateway console. fromID/name là "người gửi" giả lập dùng để test
// quyền hạn (ví dụ đặt trùng với superIds trong config để test lệnh admin).
func New(fromID, name string) *Client {
	if fromID == "" {
		fromID = "console-user"
	}
	if name == "" {
		name = "Bạn"
	}
	return &Client{chatID: "console", fromID: fromID, name: name}
}

func (c *Client) Name() string { return "console" }

func (c *Client) Run(ctx context.Context, h bot.Handler) error {
	fmt.Println("── Console test gateway ── gõ lệnh để test (vd: .menu), gõ \"exit\" để thoát ──")
	sc := bufio.NewScanner(os.Stdin)
	n := 0
	for sc.Scan() {
		if ctx.Err() != nil {
			return nil
		}
		text := strings.TrimSpace(sc.Text())
		if text == "" {
			continue
		}
		if text == "exit" {
			return nil
		}
		n++
		h.OnMessage(ctx, &bot.Message{
			ID:       fmt.Sprintf("console-%d", n),
			ChatID:   c.chatID,
			ChatType: bot.ChatPrivate,
			FromID:   c.fromID,
			FromName: c.name,
			Text:     text,
		})
	}
	return sc.Err()
}

func (c *Client) SendText(_ context.Context, _, text string) error {
	fmt.Printf("🤖 %s\n", text)
	return nil
}

func (c *Client) SendImage(_ context.Context, _, imageURL, caption string) error {
	fmt.Printf("🤖 [ảnh] %s\n   %s\n", imageURL, caption)
	return nil
}

func (c *Client) Typing(_ context.Context, _ string) error {
	fmt.Println("🤖 (đang nhập...)")
	return nil
}
