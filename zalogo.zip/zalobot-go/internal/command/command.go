// Package command: registry + dispatcher cho lệnh dạng plugin.
// Python quét thư mục src/ và đọc biến `dependencies`; Go dùng init() + Register() lúc biên dịch.
package command

import (
	"context"
	"sort"
	"sync"

	"github.com/yourname/zalobot-go/internal/bot"
)

// Cấp quyền, giữ nguyên thang 0..5 của bản gốc.
const (
	PermUser    = 0
	PermMod     = 1 // quản trị viên nhóm do bot cấp
	PermAdmin   = 2
	PermOwner   = 3
	PermRoot    = 4
	PermSupreme = 5
)

// Context chứa mọi thứ một lệnh cần.
type Context struct {
	context.Context
	Bot  *bot.Bot
	Msg  *bot.Message
	Cmd  string   // tên lệnh thật (sau khi giải alias)
	Args []string // phần còn lại sau tên lệnh
	Raw  string   // text sau tên lệnh
}

func (c *Context) Reply(text string) error {
	return c.Bot.GW.SendText(c, c.Msg.ChatID, text)
}

type Handler func(c *Context) error

// Command: tương đương dict `dependencies`.
type Command struct {
	Name        string
	Alias       []string
	Description string
	Permission  int
	Cooldown    float64 // giây
	NoPrefix    bool
	MainOnly    bool
	Hidden      bool
	Run         Handler
}

var (
	mu       sync.RWMutex
	registry = map[string]*Command{}
)

func Register(c *Command) {
	mu.Lock()
	defer mu.Unlock()
	if c.Name == "" || c.Run == nil {
		panic("command: thiếu Name/Run")
	}
	if _, dup := registry[c.Name]; dup {
		panic("command: trùng tên " + c.Name)
	}
	registry[c.Name] = c
}

func Get(name string) *Command {
	mu.RLock()
	defer mu.RUnlock()
	return registry[name]
}

func All() []*Command {
	mu.RLock()
	defer mu.RUnlock()
	out := make([]*Command, 0, len(registry))
	for _, c := range registry {
		out = append(out, c)
	}
	sort.Slice(out, func(i, j int) bool { return out[i].Name < out[j].Name })
	return out
}
