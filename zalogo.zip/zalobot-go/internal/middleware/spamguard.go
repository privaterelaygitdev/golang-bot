// Package middleware: các bộ lọc chạy trước dispatcher (spamGuard, blacklist...).
package middleware

import (
	"context"
	"sync"
	"time"

	"github.com/yourname/zalobot-go/internal/bot"
)

// SpamGuard: tối đa `limit` tin / `window` cho mỗi user, vượt ngưỡng thì bỏ qua.
func SpamGuard(limit int, window time.Duration) func(context.Context, *bot.Bot, *bot.Message) bool {
	var mu sync.Mutex
	hits := map[string][]time.Time{}
	return func(_ context.Context, b *bot.Bot, m *bot.Message) bool {
		key := b.ID + "|" + m.FromID
		now := time.Now()
		mu.Lock()
		defer mu.Unlock()
		keep := hits[key][:0]
		for _, t := range hits[key] {
			if now.Sub(t) < window {
				keep = append(keep, t)
			}
		}
		keep = append(keep, now)
		hits[key] = keep
		return len(keep) <= limit
	}
}

// Blacklist chặn user theo UID.
func Blacklist(ids ...string) func(context.Context, *bot.Bot, *bot.Message) bool {
	set := map[string]struct{}{}
	for _, id := range ids {
		set[id] = struct{}{}
	}
	return func(_ context.Context, _ *bot.Bot, m *bot.Message) bool {
		_, banned := set[m.FromID]
		return !banned
	}
}
