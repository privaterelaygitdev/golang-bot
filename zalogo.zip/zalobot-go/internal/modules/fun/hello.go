// Package fun: các lệnh giải trí — module ví dụ. Muốn thêm nhóm lệnh giải trí
// khác (tuyenduong, ngu, dzai...) thì tạo thư mục mới, đừng nhét hết vào đây.
package fun

import "github.com/yourname/zalobot-go/internal/command"

func init() {
	command.Register(&command.Command{
		Name: "hello", Alias: []string{"hi"}, Description: "Chào bạn",
		Permission: command.PermUser, Cooldown: 3,
		Run: func(c *command.Context) error { return c.Reply("Xin chào " + c.Msg.FromName) },
	})
}
