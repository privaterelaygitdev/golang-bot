// Package store: lưu JSON an toàn (ghi atomic + mutex), thay cho assets/storage/{uid}/*.json.
package store

import (
	"encoding/json"
	"errors"
	"os"
	"path/filepath"
	"sync"
)

type JSON struct {
	mu   sync.Mutex
	path string
}

func NewJSON(path string) *JSON { return &JSON{path: path} }

func (s *JSON) Load(v any) error {
	s.mu.Lock()
	defer s.mu.Unlock()
	b, err := os.ReadFile(s.path)
	if errors.Is(err, os.ErrNotExist) {
		return nil
	}
	if err != nil {
		return err
	}
	return json.Unmarshal(b, v)
}

// Update đọc → sửa → ghi trong một khoá, tránh race giữa các goroutine.
func (s *JSON) Update(v any, fn func()) error {
	s.mu.Lock()
	defer s.mu.Unlock()
	if b, err := os.ReadFile(s.path); err == nil {
		_ = json.Unmarshal(b, v)
	}
	fn()
	return s.write(v)
}

func (s *JSON) Save(v any) error {
	s.mu.Lock()
	defer s.mu.Unlock()
	return s.write(v)
}

func (s *JSON) write(v any) error {
	if err := os.MkdirAll(filepath.Dir(s.path), 0o755); err != nil {
		return err
	}
	b, err := json.MarshalIndent(v, "", "  ")
	if err != nil {
		return err
	}
	tmp := s.path + ".tmp"
	if err := os.WriteFile(tmp, b, 0o600); err != nil {
		return err
	}
	return os.Rename(tmp, s.path)
}
