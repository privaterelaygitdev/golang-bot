// Package core: các lệnh nền tảng của bot (ping, uid, menu, prefix).
// Mỗi file trong package này tự đăng ký lệnh của mình qua init() — thêm lệnh
// mới cho nhóm "core" bằng cách thêm file .go mới vào đúng thư mục này.
package core

import (
	"fmt"
	"strings"

	"github.com/yourname/zalobot-go/internal/command"
	"github.com/yourname/zalobot-go/internal/store"
)

func init() {
	command.Register(&command.Command{
		Name: "ping", Description: "Kiểm tra bot còn sống", Cooldown: 3,
		Run: func(c *command.Context) error { return c.Reply("pong 🏓") },
	})

	command.Register(&command.Command{
		Name: "uid", Alias: []string{"id"}, Description: "Lấy UID của bạn", Cooldown: 5,
		Run: func(c *command.Context) error {
			return c.Reply(fmt.Sprintf("UID: %s\nChat: %s", c.Msg.FromID, c.Msg.ChatID))
		},
	})

	command.Register(&command.Command{
		Name: "menu", Alias: []string{"help"}, Description: "Danh sách lệnh",
		Run: func(c *command.Context) error {
			lvl := command.Level(c.Bot, c.Msg.FromID, c.Msg.ChatID)
			var sb strings.Builder
			sb.WriteString("📜 MENU\n")
			for _, cmd := range command.All() {
				if cmd.Hidden || cmd.Permission > lvl || (cmd.MainOnly && !c.Bot.Main) {
					continue
				}
				fmt.Fprintf(&sb, "• %s — %s\n", cmd.Name, cmd.Description)
			}
			return c.Reply(sb.String())
		},
	})

	command.Register(&command.Command{
		Name: "prefix", Description: "Đổi prefix: prefix ! | prefix none", Permission: command.PermAdmin,
		Run: func(c *command.Context) error {
			if len(c.Args) == 0 {
				return c.Reply(fmt.Sprintf("Prefix hiện tại: %q", c.Bot.Prefixes()))
			}
			p := strings.Join(c.Args, " ")
			if strings.EqualFold(p, "none") {
				p = ""
			}
			c.Bot.SetPrefix(p)
			_ = c.Bot.Store.UpdateSettings(func(s *store.Settings) { s.Prefix = p })
			return c.Reply("Đã đổi prefix ✅")
		},
	})
}
