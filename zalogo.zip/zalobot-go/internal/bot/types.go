// Package bot chứa các kiểu dữ liệu lõi dùng chung toàn dự án.
package bot

import "context"

type ChatType string

const (
	ChatPrivate ChatType = "PRIVATE"
	ChatGroup   ChatType = "GROUP"
)

// Message là tin nhắn đã được chuẩn hoá, độc lập với transport (Zalo Bot API / tài khoản cá nhân).
// Tương ứng (mid, userId, message, data, threadId, type) trong messageListener của bản Python.
type Message struct {
	ID       string
	ChatID   string // threadId
	ChatType ChatType
	FromID   string // userId
	FromName string
	Text     string
	Mentions []Mention
	ReplyTo  string
	Raw      any // payload gốc của gateway
}

type Mention struct {
	UID string
	Pos int
	Len int
}

// Event: sự kiện không phải tin nhắn (join/leave group, reaction, undo...).
type Event struct {
	Type    string
	ChatID  string
	ActorID string
	Targets []string
	Raw     any
}

// Gateway là cổng nói chuyện với Zalo. Thay transport chỉ cần cài interface này.
type Gateway interface {
	Name() string
	// Run chặn cho tới khi ctx bị huỷ; đẩy message/event vào handler.
	Run(ctx context.Context, h Handler) error
	Sender
}

// Sender: các hành động gửi đi.
type Sender interface {
	SendText(ctx context.Context, chatID, text string) error
	SendImage(ctx context.Context, chatID, imageURL, caption string) error
	Typing(ctx context.Context, chatID string) error
}

// Handler nhận dữ liệu từ gateway (tương đương MessageHandler / EventListener).
type Handler interface {
	OnMessage(ctx context.Context, m *Message)
	OnEvent(ctx context.Context, e *Event)
}
