package bot

import (
	"strings"
	"sync/atomic"

	"github.com/yourname/zalobot-go/internal/store"
)

// Bot = một instance bot (tương đương class ebugZLB trong bản Python).
// Mỗi tài khoản/token là một Bot, chạy trong goroutine riêng.
type Bot struct {
	ID       string
	Name     string
	Main     bool // bot chính: có thêm quyền quản lý multibot
	GW       Gateway
	Store    *store.BotStore
	SuperIDs []string // admin cứng (cấp 5)

	prefixes atomic.Value // []string
	running  atomic.Bool
}

func New(id, name string, main bool, gw Gateway, st *store.BotStore, prefix string, supers []string) *Bot {
	b := &Bot{ID: id, Name: name, Main: main, GW: gw, Store: st, SuperIDs: supers}
	b.SetPrefix(prefix)
	return b
}

// SetPrefix: "" = không cần prefix; "! ." = nhiều prefix.
func (b *Bot) SetPrefix(p string) {
	b.prefixes.Store(strings.Fields(strings.ReplaceAll(p, ",", " ")))
}

func (b *Bot) Prefixes() []string {
	v, _ := b.prefixes.Load().([]string)
	return v
}

func (b *Bot) SetRunning(v bool) { b.running.Store(v) }
func (b *Bot) Running() bool     { return b.running.Load() }
