package command

import (
	"context"
	"fmt"
	"log/slog"
	"strings"
	"sync"
	"time"

	"github.com/yourname/zalobot-go/internal/bot"
)

// Middleware chạy trước khi tìm lệnh; trả false để chặn (spam, blacklist...).
type Middleware func(ctx context.Context, b *bot.Bot, m *bot.Message) bool

type Dispatcher struct {
	mw       []Middleware
	mu       sync.Mutex
	cooldown map[string]time.Time
}

func NewDispatcher(mw ...Middleware) *Dispatcher {
	return &Dispatcher{mw: mw, cooldown: map[string]time.Time{}}
}

// SyncStore ghi danh sách lệnh vào Command.json của bot (giống SyncCommandData).
func SyncStore(b *bot.Bot) error {
	return b.Store.SyncCommands(defs())
}

// Handle = LoadCommands() của bản Python.
func (d *Dispatcher) Handle(ctx context.Context, b *bot.Bot, m *bot.Message) {
	text := strings.TrimSpace(m.Text)
	if text == "" {
		return
	}
	for _, f := range d.mw {
		if !f(ctx, b, m) {
			return
		}
	}

	rest, hasPrefix := stripPrefix(b.Prefixes(), text)
	if !hasPrefix {
		return
	}
	fields := strings.Fields(rest)
	if len(fields) == 0 {
		return
	}
	raw := strings.ToLower(fields[0])

	confs := b.Store.CommandConfs()
	cmd := Get(raw)
	real := raw
	if cmd == nil { // giải alias theo cấu hình từng bot
		for name, cf := range confs {
			for _, a := range cf.Alias {
				if a == raw {
					cmd, real = Get(name), name
				}
			}
		}
	}
	if cmd == nil || (cmd.MainOnly && !b.Main) {
		return
	}

	perm, cd, enabled := cmd.Permission, cmd.Cooldown, true
	if cf, ok := confs[real]; ok { // Command.json ghi đè mặc định trong code
		perm, cd, enabled = cf.Permission, cf.Cooldown, cf.Status
	}
	if !enabled {
		return
	}
	if lvl := Level(b, m.FromID, m.ChatID); lvl < perm {
		_ = b.GW.SendText(ctx, m.ChatID, fmt.Sprintf("Bạn không đủ quyền (cần cấp %d, bạn cấp %d).", perm, lvl))
		return
	}
	if wait := d.checkCooldown(b.ID, m.FromID, real, cd); wait > 0 {
		_ = b.GW.SendText(ctx, m.ChatID, fmt.Sprintf("Vui lòng đợi %.0fs.", wait.Seconds()))
		return
	}

	c := &Context{Context: ctx, Bot: b, Msg: m, Cmd: real, Args: fields[1:],
		Raw: strings.TrimSpace(strings.TrimPrefix(rest, fields[0]))}
	defer func() {
		if r := recover(); r != nil { // một lệnh panic không được làm sập bot
			slog.Error("command panic", "cmd", real, "err", r)
		}
	}()
	if err := cmd.Run(c); err != nil {
		slog.Error("command error", "cmd", real, "err", err)
	}
}

func (d *Dispatcher) checkCooldown(botID, uid, cmd string, sec float64) time.Duration {
	if sec <= 0 {
		return 0
	}
	key := botID + "|" + uid + "|" + cmd
	now := time.Now()
	d.mu.Lock()
	defer d.mu.Unlock()
	if len(d.cooldown) > 10000 { // dọn bớt như bản gốc
		for k, t := range d.cooldown {
			if now.Sub(t) > time.Hour {
				delete(d.cooldown, k)
			}
		}
	}
	if last, ok := d.cooldown[key]; ok {
		if remain := time.Duration(sec*float64(time.Second)) - now.Sub(last); remain > 0 {
			return remain
		}
	}
	d.cooldown[key] = now
	return 0
}

// stripPrefix: prefix rỗng (danh sách rỗng) = chế độ không cần prefix.
func stripPrefix(prefixes []string, text string) (string, bool) {
	if len(prefixes) == 0 {
		return text, true
	}
	for _, p := range prefixes {
		if strings.HasPrefix(text, p) {
			return strings.TrimSpace(strings.TrimPrefix(text, p)), true
		}
	}
	return text, false
}
